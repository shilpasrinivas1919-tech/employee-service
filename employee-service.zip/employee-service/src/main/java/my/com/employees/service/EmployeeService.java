package my.com.employees.service;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import my.com.employees.dto.EmployeeRequest;
import my.com.employees.dto.EmployeeResponse;
import my.com.employees.exception.ResourceNotFoundException;
import my.com.employees.model.Department;
import my.com.employees.model.Employee;
import my.com.employees.repository.DepartmentRepository;
import my.com.employees.repository.EmployeeRepository;

@Service
@Transactional(readOnly = true)
public class EmployeeService {
	private final EmployeeRepository employeeRepository;
	private final DepartmentRepository departmentRepository;

	public EmployeeService(EmployeeRepository employeeRepository, DepartmentRepository departmentRepository) {
		this.employeeRepository = employeeRepository;
		this.departmentRepository = departmentRepository;
	}

	public EmployeeResponse getEmployeeById(Long id) {
		return toResponse(findEmployeeById(id));
	}

	public Page<EmployeeResponse> searchEmployee(String keyword, int page, int size) {
		if (page < 0 || size < 1 || size > 100)
			throw new IllegalArgumentException("page must be >= 0 and size must be between 1 and 100");
		Pageable pageable = PageRequest.of(page, size, Sort.by("name").ascending());
		Page<Employee> result = keyword == null || keyword.isBlank() ? employeeRepository.findAll(pageable)
				: employeeRepository.search(keyword.trim(), pageable);
		return result.map(this::toResponse);
	}

	@Transactional
	public EmployeeResponse createEmployee(EmployeeRequest request) {
		Department department = findDepartment(request.departmentId());
		try {
			return toResponse(employeeRepository
					.save(new Employee(request.name().trim(), request.email().trim(), request.salary(), department)));
		} catch (DataIntegrityViolationException ex) {
			throw new IllegalArgumentException("Employee email already exists");
		}
	}

	@Transactional
	public EmployeeResponse updateEmployee(Long id, EmployeeRequest request) {
		Employee employee = findEmployeeById(id);
		employee.setName(request.name().trim());
		employee.setEmail(request.email().trim());
		employee.setSalary(request.salary());
		employee.setDepartment(findDepartment(request.departmentId()));
		try {
			return toResponse(employeeRepository.save(employee));
		} catch (DataIntegrityViolationException ex) {
			throw new IllegalArgumentException("Employee email already exists");
		}
	}

	@Transactional
	public void deleteEmployee(Long id) {
		employeeRepository.delete(findEmployeeById(id));
	}

	private Employee findEmployeeById(Long id) {
		return employeeRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Employee not found: " + id));
	}

	private Department findDepartment(Long id) {
		return departmentRepository.findById(id)
				.orElseThrow(() -> new ResourceNotFoundException("Department not found: " + id));
	}

	private EmployeeResponse toResponse(Employee e) {
		return new EmployeeResponse(e.getId(), e.getName(), e.getEmail(), e.getSalary(), e.getDepartment().getId(),
				e.getDepartment().getName());
	}
}
