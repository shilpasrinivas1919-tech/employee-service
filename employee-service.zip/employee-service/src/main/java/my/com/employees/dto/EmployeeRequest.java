package my.com.employees.dto;

import jakarta.validation.constraints.*;
import java.math.BigDecimal;

public record EmployeeRequest(
        @NotBlank @Size(max = 100) String name,
        @NotBlank @Email @Size(max = 120) String email,
        @NotNull @DecimalMin("0.0") BigDecimal salary,
        @NotNull @Positive Long departmentId) { }
