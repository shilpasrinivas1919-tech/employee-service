package my.com.employees.logging;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.*;
import org.slf4j.*;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.*;
import java.util.Arrays;

@Aspect
@Component
public class LoggingAspect {
	private static final Logger log = LoggerFactory.getLogger(LoggingAspect.class);
	private final ObjectMapper mapper;

	public LoggingAspect(ObjectMapper mapper) {
		this.mapper = mapper;
	}

	@Around("within(@org.springframework.web.bind.annotation.RestController *)")
	public Object logCall(ProceedingJoinPoint joinPoint) throws Throwable {
		HttpServletRequest request = currentRequest();
		long started = System.currentTimeMillis();
		String method = request == null ? "N/A" : request.getMethod();
		String path = request == null ? "N/A" : request.getRequestURI();
		try {
			log.info("Request method={} path={} handler={} arguments={}", method, path,
					joinPoint.getSignature().toShortString(), toJson(joinPoint.getArgs()));
			Object result = joinPoint.proceed();
			log.info("Response method={} path={} durationMs={} body={}", method, path,
					System.currentTimeMillis() - started, toJson(result));
			return result;
		} catch (Throwable ex) {
			log.error("Request failed method={} path={} durationMs={} error={}", method, path,
					System.currentTimeMillis() - started, ex.getMessage());
			throw ex;
		}
	}

	private HttpServletRequest currentRequest() {
		RequestAttributes attrs = RequestContextHolder.getRequestAttributes();
		return attrs instanceof ServletRequestAttributes s ? s.getRequest() : null;
	}

	private String toJson(Object value) {
		try {
			return mapper.writeValueAsString(value);
		} catch (Exception ex) {
			return Arrays.toString(value instanceof Object[] a ? a : new Object[] { value });
		}
	}
}
