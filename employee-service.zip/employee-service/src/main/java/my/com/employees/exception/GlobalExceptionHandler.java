package my.com.employees.exception;

import java.time.Instant;
import java.util.Map;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

@RestControllerAdvice
public class GlobalExceptionHandler {
	@ExceptionHandler(ResourceNotFoundException.class)
	ResponseEntity<ApiError> notFound(ResourceNotFoundException ex) {
		return response(HttpStatus.NOT_FOUND, ex.getMessage(), Map.of());
	}

	@ExceptionHandler(IllegalArgumentException.class)
	ResponseEntity<ApiError> badRequest(IllegalArgumentException ex) {
		return response(HttpStatus.BAD_REQUEST, ex.getMessage(), Map.of());
	}

	private ResponseEntity<ApiError> response(HttpStatus status, String message, Map<String, String> errors) {
		return ResponseEntity.status(status).body(new ApiError(Instant.now(), status.value(), message, errors));
	}
}
