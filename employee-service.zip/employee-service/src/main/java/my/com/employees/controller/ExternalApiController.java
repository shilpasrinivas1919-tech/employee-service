package my.com.employees.controller;

import org.springframework.web.bind.annotation.*;

import my.com.employees.service.ExternalApiService;

import java.util.Map;

@RestController
@RequestMapping("/api/external")
public class ExternalApiController {
	private final ExternalApiService service;

	public ExternalApiController(ExternalApiService service) {
		this.service = service;
	}

	@GetMapping("/todo")
	public Map<?, ?> todo() {
		return service.fetchSampleTodo();
	}
}
