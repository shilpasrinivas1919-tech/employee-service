package my.com.employees.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import my.com.employees.dto.ExternalApiResponse;
import my.com.employees.service.ExternalApiService;

@RestController
@RequestMapping("/api/external")
public class ExternalApiController {
	
	private final ExternalApiService service;

	public ExternalApiController(ExternalApiService service) {
		this.service = service;
	}

	@GetMapping("/todo")
	public ExternalApiResponse todo() {
		return service.fetchSampleTodo();
	}
}
