package my.com.employees.service;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClient;
import java.util.Map;

@Service
public class ExternalApiService {
	private final RestClient restClient;
	private final String url;

	public ExternalApiService(RestClient restClient, @Value("${external.todo-url}") String url) {
		this.restClient = restClient;
		this.url = url;
	}

	public Map<?, ?> fetchSampleTodo() {
		Map<?, ?> response = restClient.get().uri(url).retrieve().body(Map.class);
		if (response == null)
			throw new IllegalStateException("External service returned an empty response");
		return response;
	}
}
