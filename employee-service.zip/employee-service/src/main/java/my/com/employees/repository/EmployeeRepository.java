package my.com.employees.repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;

import my.com.employees.model.Employee;

public interface EmployeeRepository extends JpaRepository<Employee, Long> {
	@Query("""
			select e from Employee e
			where lower(e.name) like lower(concat('%', :keyword, '%'))
			   or lower(e.email) like lower(concat('%', :keyword, '%'))
			""")
	Page<Employee> search(@Param("keyword") String keyword, Pageable pageable);

}
