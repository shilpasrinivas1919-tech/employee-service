package my.com.employees.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import my.com.employees.model.Department;

public interface DepartmentRepository extends JpaRepository<Department, Long> { }
