package my.com.employees.dto;

public record ExternalApiResponse(Long userId, Long id, String title, Boolean completed) {

}
