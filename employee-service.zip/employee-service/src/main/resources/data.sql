insert into departments(name) values ('Engineering');
insert into departments(name) values ('Operations');

insert into employees(name, email, salary, department_id) values ('Shilpa S', 'shilpa.sharma@gmail.com', 5500.00, 1);
insert into employees(name, email, salary, department_id) values ('Rahul Verma', 'rahul.verma@gmail.com', 6200.00, 2);
insert into employees(name, email, salary, department_id) values ('Priya Singh', 'priya.singh@gmail.com', 5800.00, 1);
insert into employees(name, email, salary, department_id) values ('Ankit Gupta', 'ankit.gupta@gmail.com', 6100.00, 2);
insert into employees(name, email, salary, department_id) values ('Neha Patel', 'neha.patel@gmail.com', 5900.00, 1);
insert into employees(name, email, salary, department_id) values ('Rohit Kumar', 'rohit.kumar@gmail.com', 6700.00, 2);
insert into employees(name, email, salary, department_id) values ('Pooja Nair', 'pooja.nair@gmail.com', 5600.00, 1);
insert into employees(name, email, salary, department_id) values ('Sandeep Rao', 'sandeep.rao@gmail.com', 6400.00, 2);
insert into employees(name, email, salary, department_id) values ('Kavita Joshi', 'kavita.joshi@gmail.com', 5700.00, 1);
insert into employees(name, email, salary, department_id) values ('Vikas Mehta', 'vikas.mehta@gmail.com', 6800.00, 2);

insert into employees(name, email, salary, department_id) values ('Deepak Yadav', 'deepak.yadav@gmail.com', 6000.00, 1);
insert into employees(name, email, salary, department_id) values ('Sneha Reddy', 'sneha.reddy@gmail.com', 6300.00, 2);
insert into employees(name, email, salary, department_id) values ('Arjun Raina', 'arjun.raina@gmail.com', 6100.00, 1);
insert into employees(name, email, salary, department_id) values ('Meera Iyer', 'meera.iyer@gmail.com', 5900.00, 2);
insert into employees(name, email, salary, department_id) values ('Nikhil Jain', 'nikhil.jain@gmail.com', 6200.00, 1);
insert into employees(name, email, salary, department_id) values ('Shweta Das', 'shweta.das@gmail.com', 5800.00, 2);
insert into employees(name, email, salary, department_id) values ('Ajay Menon', 'ajay.menon@gmail.com', 6500.00, 1);
insert into employees(name, email, salary, department_id) values ('Ritu Kapoor', 'ritu.kapoor@gmail.com', 5700.00, 2);
insert into employees(name, email, salary, department_id) values ('Manoj Babu', 'manoj.babu@gmail.com', 6600.00, 1);
insert into employees(name, email, salary, department_id) values ('Divya Nair', 'divya.nair@gmail.com', 6000.00, 2);

insert into employees(name, email, salary, department_id) values ('Kiran Rao', 'kiran.rao@gmail.com', 5900.00, 1);
insert into employees(name, email, salary, department_id) values ('Harish Kumar', 'harish.kumar@gmail.com', 6800.00, 2);
insert into employees(name, email, salary, department_id) values ('Anjali Gupta', 'anjali.gupta@gmail.com', 6200.00, 1);
insert into employees(name, email, salary, department_id) values ('Suresh Patel', 'suresh.patel@gmail.com', 6400.00, 2);
insert into employees(name, email, salary, department_id) values ('Monika Sharma', 'monika.sharma@gmail.com', 5700.00, 1);
insert into employees(name, email, salary, department_id) values ('Vivek Singh', 'vivek.singh@gmail.com', 6900.00, 2);
insert into employees(name, email, salary, department_id) values ('Rekha Jain', 'rekha.jain@gmail.com', 5600.00, 1);
insert into employees(name, email, salary, department_id) values ('Tarun Verma', 'tarun.verma@gmail.com', 6100.00, 2);
insert into employees(name, email, salary, department_id) values ('Pallavi Rao', 'pallavi.rao@gmail.com', 6000.00, 1);
insert into employees(name, email, salary, department_id) values ('Gaurav Mehta', 'gaurav.mehta@gmail.com', 7000.00, 2);

insert into employees(name, email, salary, department_id) values ('Ramesh Kumar', 'ramesh.kumar@gmail.com', 5800.00, 1);
insert into employees(name, email, salary, department_id) values ('Sunita Devi', 'sunita.devi@gmail.com', 5500.00, 2);
insert into employees(name, email, salary, department_id) values ('Varun Sharma', 'varun.sharma@gmail.com', 6300.00, 1);
insert into employees(name, email, salary, department_id) values ('Asha Patel', 'asha.patel@gmail.com', 5900.00, 2);
insert into employees(name, email, salary, department_id) values ('Naveen Gupta', 'naveen.gupta@gmail.com', 6200.00, 1);
insert into employees(name, email, salary, department_id) values ('Bhavna Singh', 'bhavna.singh@gmail.com', 6100.00, 2);
insert into employees(name, email, salary, department_id) values ('Rakesh Yadav', 'rakesh.yadav@gmail.com', 6500.00, 1);
insert into employees(name, email, salary, department_id) values ('Latha Menon', 'latha.menon@gmail.com', 5700.00, 2);
insert into employees(name, email, salary, department_id) values ('Ashok Reddy', 'ashok.reddy@gmail.com', 6800.00, 1);
insert into employees(name, email, salary, department_id) values ('Jyoti Nair', 'jyoti.nair@gmail.com', 6000.00, 2);

insert into employees(name, email, salary, department_id) values ('Prakash Rao', 'prakash.rao@gmail.com', 6400.00, 1);
insert into employees(name, email, salary, department_id) values ('Sonia Kapoor', 'sonia.kapoor@gmail.com', 5900.00, 2);
insert into employees(name, email, salary, department_id) values ('Mohan Das', 'mohan.das@gmail.com', 6600.00, 1);
insert into employees(name, email, salary, department_id) values ('Komal Jain', 'komal.jain@gmail.com', 5700.00, 2);
insert into employees(name, email, salary, department_id) values ('Santosh Kumar', 'santosh.kumar@gmail.com', 6200.00, 1);
insert into employees(name, email, salary, department_id) values ('Preeti Verma', 'preeti.verma@gmail.com', 6100.00, 2);
insert into employees(name, email, salary, department_id) values ('Vijay Sharma', 'vijay.sharma@gmail.com', 7000.00, 1);
insert into employees(name, email, salary, department_id) values ('Nandini Rao', 'nandini.rao@gmail.com', 5800.00, 2);
insert into employees(name, email, salary, department_id) values ('Arvind Patel', 'arvind.patel@gmail.com', 6500.00, 1);
insert into employees(name, email, salary, department_id) values ('Harini Iyer', 'harini.iyer@gmail.com', 6000.00, 2);