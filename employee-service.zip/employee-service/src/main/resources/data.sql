insert into departments(name) values ('Engineering');
insert into departments(name) values ('Operations');
insert into employees(name, email, salary, department_id) values ('Shilpa', 'shilpa@gmail.com', 6000.00, 1);
insert into employees(name, email, salary, department_id) values ('Ramu', 'ram@gmail.com', 5500.00, 2);
insert into employees(name, email, salary, department_id) values ('Ramesh', 'ramesh@gmail.com', 7200.00, 1);
