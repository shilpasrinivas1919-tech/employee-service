package my.com.employees.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.boot.test.web.client.TestRestTemplate;
import org.springframework.http.*;

import my.com.employees.dto.EmployeeRequest;
import my.com.employees.dto.EmployeeResponse;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest(webEnvironment = SpringBootTest.WebEnvironment.RANDOM_PORT)
class EmployeeControllerTest {

	@Autowired
	private TestRestTemplate restTemplate;

	@Test
	void shouldGetEmployee() {

		ResponseEntity<EmployeeResponse> response = restTemplate.getForEntity("/api/employees/1",
				EmployeeResponse.class);

		assertEquals(HttpStatus.OK, response.getStatusCode());

		assertNotNull(response.getBody());
	}

	@Test
	void shouldCreateEmployee() {

		EmployeeRequest request = new EmployeeRequest("Rahul Sharma", "rahul@test.com", new BigDecimal("6500"), 1L);

		ResponseEntity<EmployeeResponse> response = restTemplate.postForEntity("/api/employees", request,
				EmployeeResponse.class);

		assertEquals(HttpStatus.CREATED, response.getStatusCode());

		assertNotNull(response.getBody());
		assertEquals("Rahul Sharma", response.getBody().name());
	}
}