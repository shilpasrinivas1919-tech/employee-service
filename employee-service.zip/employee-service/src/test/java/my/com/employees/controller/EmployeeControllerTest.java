package my.com.employees.controller;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import my.com.employees.dto.EmployeeResponse;
import my.com.employees.service.EmployeeService;

import java.math.BigDecimal;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(EmployeeController.class)
class EmployeeControllerTest {
    @Autowired MockMvc mockMvc;
    @MockitoBean EmployeeService service;

    @Test void returnsEmployeeById() throws Exception {
        when(service.get(1L)).thenReturn(new EmployeeResponse(1L, "John", "john@example.com", new BigDecimal("5000"), 1L, "Engineering"));
        mockMvc.perform(get("/api/employees/1"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.name").value("John"))
                .andExpect(jsonPath("$.departmentName").value("Engineering"));
    }
}
