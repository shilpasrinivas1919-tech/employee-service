package my.com.employees.service;

import my.com.employees.dto.EmployeeRequest;
import my.com.employees.dto.EmployeeResponse;
import my.com.employees.model.Department;
import my.com.employees.model.Employee;
import my.com.employees.repository.DepartmentRepository;
import my.com.employees.repository.EmployeeRepository;

import org.junit.jupiter.api.*;
import org.mockito.*;
import java.math.BigDecimal;
import java.util.Optional;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

class EmployeeServiceTest {
    @Mock EmployeeRepository employeeRepository;
    @Mock DepartmentRepository departmentRepository;
    @InjectMocks EmployeeService service;

    @BeforeEach void setUp() { MockitoAnnotations.openMocks(this); }

    @Test void createsEmployeeWhenDepartmentExists() {
        Department department = new Department("Engineering");
        when(departmentRepository.findById(1L)).thenReturn(Optional.of(department));
        when(employeeRepository.save(any(Employee.class))).thenAnswer(i -> i.getArgument(0));
        EmployeeResponse result = service.create(new EmployeeRequest("John", "john@example.com", new BigDecimal("5000"), 1L));
        assertEquals("John", result.name());
        assertEquals("Engineering", result.departmentName());
        verify(employeeRepository).save(any(Employee.class));
    }
}
