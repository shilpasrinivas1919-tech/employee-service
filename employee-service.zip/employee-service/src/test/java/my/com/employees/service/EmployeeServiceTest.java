package my.com.employees.service;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import my.com.employees.dto.EmployeeRequest;
import my.com.employees.dto.EmployeeResponse;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

@SpringBootTest
class EmployeeServiceTest {

	@Autowired
	private EmployeeService employeeService;

	@Test
	void shouldCreateEmployee() {

		EmployeeRequest request = new EmployeeRequest("John Kumar", "john.kumar@test.com", new BigDecimal("5000"), 1L);

		EmployeeResponse response = employeeService.createEmployee(request);

		assertNotNull(response);
		assertNotNull(response.id());
		assertEquals("John Kumar", response.name());
		assertEquals("john.kumar@test.com", response.email());
	}

	@Test
	void shouldFindEmployeeById() {

		EmployeeResponse employee = employeeService.getEmployeeById(1L);

		assertNotNull(employee);
		assertEquals(1L, employee.id());
	}
}